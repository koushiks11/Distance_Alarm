package com.example.distancealarm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Download_page_after_login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_download_page_after_login);
    }
}